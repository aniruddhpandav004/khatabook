class ProductModal
{
  String? name,mobile,address;

  ProductModal({this.name, this.mobile, this.address});
}