class DataModal
{
  String? name,mobile,address,id;

  DataModal({this.name, this.mobile, this.address,this.id});
}